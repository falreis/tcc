namespace GoogleMapsApi.Entities.Common
{
	public interface ILocationString
	{
		string LocationString { get; }
	}
}