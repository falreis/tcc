namespace GoogleMapsApi.Entities.Common
{
	public interface IResponseFor<T> where T : MapsBaseRequest { }
}