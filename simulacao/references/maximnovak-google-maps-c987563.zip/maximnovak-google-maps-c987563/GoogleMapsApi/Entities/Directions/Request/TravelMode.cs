﻿namespace GoogleMapsApi.Entities.Directions.Request
{
	public enum TravelMode
	{
		Driving,
		Walking,
		Bicycling,
		Transit
	}
}
