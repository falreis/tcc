namespace GoogleMapsApi.StaticMaps.Enums
{
	public enum MapVisibility
	{
		On,
		Off,
		Simplified
	}
}