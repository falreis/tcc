namespace GoogleMapsApi.StaticMaps.Enums
{
	public enum MarkerSize
	{
		Mid,
		Tiny,
		Small
	}
}